#!/bin/sh
# Builtin Light
printf "\033]4;0;#000000;1;#bb0000;2;#00bb00;3;#bbbb00;4;#0000bb;5;#bb00bb;6;#00bbbb;7;#bbbbbb;8;#555555;9;#ff5555;10;#55ff55;11;#ffff55;12;#5555ff;13;#ff55ff;14;#55ffff;15;#ffffff\007"
printf "\033]10;#000000;#ffffff;#000000\007"
printf "\033]17;#b5d5ff\007"
printf "\033]19;#000000\007"
printf "\033]5;0;#000000\007"
