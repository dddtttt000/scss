#!/bin/sh
# Spring
printf "\033]4;0;#000000;1;#ff4d83;2;#1f8c3b;3;#1fc95b;4;#1dd3ee;5;#8959a8;6;#3e999f;7;#ffffff;8;#000000;9;#ff0021;10;#1fc231;11;#d5b807;12;#15a9fd;13;#8959a8;14;#3e999f;15;#ffffff\007"
printf "\033]10;#4d4d4c;#ffffff;#4d4d4c\007"
printf "\033]17;#d6d6d6\007"
printf "\033]19;#4d4d4c\007"
printf "\033]5;0;#4d4d4c\007"
