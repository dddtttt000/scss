#!/bin/sh
# Monokai Soda
printf "\033]4;0;#1a1a1a;1;#f4005f;2;#98e024;3;#fa8419;4;#9d65ff;5;#f4005f;6;#58d1eb;7;#c4c5b5;8;#625e4c;9;#f4005f;10;#98e024;11;#e0d561;12;#9d65ff;13;#f4005f;14;#58d1eb;15;#f6f6ef\007"
printf "\033]10;#c4c5b5;#1a1a1a;#f6f7ec\007"
printf "\033]17;#343434\007"
printf "\033]19;#c4c5b5\007"
printf "\033]5;0;#c4c5b5\007"
