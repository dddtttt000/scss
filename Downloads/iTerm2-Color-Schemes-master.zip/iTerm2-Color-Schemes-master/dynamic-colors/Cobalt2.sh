#!/bin/sh
# Cobalt2
printf "\033]4;0;#000000;1;#ff0000;2;#38de21;3;#ffe50a;4;#1460d2;5;#ff005d;6;#00bbbb;7;#bbbbbb;8;#555555;9;#f40e17;10;#3bd01d;11;#edc809;12;#5555ff;13;#ff55ff;14;#6ae3fa;15;#ffffff\007"
printf "\033]10;#ffffff;#132738;#f0cc09\007"
printf "\033]17;#18354f\007"
printf "\033]19;#b5b5b5\007"
printf "\033]5;0;#f7fcff\007"
