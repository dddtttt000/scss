#!/bin/sh
# BlueDolphin
printf "\033]4;0;#292d3e;1;#ff8288;2;#b4e88d;3;#f4d69f;4;#82aaff;5;#e9c1ff;6;#89ebff;7;#d0d0d0;8;#434758;9;#ff8b92;10;#ddffa7;11;#ffe585;12;#9cc4ff;13;#ddb0f6;14;#a3f7ff;15;#ffffff\007"
printf "\033]10;#c5f2ff;#006984;#ffcc00\007"
printf "\033]17;#2baeca\007"
printf "\033]19;#eceff1\007"
printf "\033]5;0;#eeeeee\007"
