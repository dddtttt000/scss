#!/bin/sh
# Abernathy
printf "\033]4;0;#000000;1;#cd0000;2;#00cd00;3;#cdcd00;4;#1093f5;5;#cd00cd;6;#00cdcd;7;#faebd7;8;#404040;9;#ff0000;10;#00ff00;11;#ffff00;12;#11b5f6;13;#ff00ff;14;#00ffff;15;#ffffff\007"
printf "\033]10;#eeeeec;#111416;#bbbbbb\007"
printf "\033]17;#eeeeec\007"
printf "\033]19;#333333\007"
printf "\033]5;0;#abb2bf\007"
