#!/bin/sh
# Square
printf "\033]4;0;#050505;1;#e9897c;2;#b6377d;3;#ecebbe;4;#a9cdeb;5;#75507b;6;#c9caec;7;#f2f2f2;8;#141414;9;#f99286;10;#c3f786;11;#fcfbcc;12;#b6defb;13;#ad7fa8;14;#d7d9fc;15;#e2e2e2\007"
printf "\033]10;#acacab;#1a1a1a;#fcfbcc\007"
printf "\033]17;#4d4d4d\007"
printf "\033]19;#ffffff\007"
printf "\033]5;0;#e5e5e5\007"
