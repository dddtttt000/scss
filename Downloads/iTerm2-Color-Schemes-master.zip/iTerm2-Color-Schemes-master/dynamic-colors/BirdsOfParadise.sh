#!/bin/sh
# BirdsOfParadise
printf "\033]4;0;#573d26;1;#be2d26;2;#6ba18a;3;#e99d2a;4;#5a86ad;5;#ac80a6;6;#74a6ad;7;#e0dbb7;8;#9b6c4a;9;#e84627;10;#95d8ba;11;#d0d150;12;#b8d3ed;13;#d19ecb;14;#93cfd7;15;#fff9d5\007"
printf "\033]10;#e0dbb7;#2a1f1d;#573d26\007"
printf "\033]17;#563c27\007"
printf "\033]19;#e0dbbb\007"
printf "\033]5;0;#fff8d8\007"
