#!/bin/sh
# Breeze
printf "\033]4;0;#31363b;1;#ed1515;2;#11d116;3;#f67400;4;#1d99f3;5;#9b59b6;6;#1abc9c;7;#eff0f1;8;#7f8c8d;9;#c0392b;10;#1cdc9a;11;#fdbc4b;12;#3daee9;13;#8e44ad;14;#16a085;15;#fcfcfc\007"
printf "\033]10;#eff0f1;#31363b;#eff0f1\007"
printf "\033]17;#eff0f1\007"
printf "\033]19;#31363b\007"
printf "\033]5;0;#fcfcfc\007"
