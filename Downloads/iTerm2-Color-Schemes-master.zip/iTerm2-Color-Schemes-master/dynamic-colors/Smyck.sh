#!/bin/sh
# Smyck
printf "\033]4;0;#000000;1;#b84131;2;#7da900;3;#c4a500;4;#62a3c4;5;#ba8acc;6;#207383;7;#a1a1a1;8;#7a7a7a;9;#d6837c;10;#c4f137;11;#fee14d;12;#8dcff0;13;#f79aff;14;#6ad9cf;15;#f7f7f7\007"
printf "\033]10;#f7f7f7;#1b1b1b;#bbbbbb\007"
printf "\033]17;#207483\007"
printf "\033]19;#f7f7f7\007"
printf "\033]5;0;#ffffff\007"
