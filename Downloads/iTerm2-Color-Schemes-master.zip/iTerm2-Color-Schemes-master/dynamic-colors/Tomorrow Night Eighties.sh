#!/bin/sh
# Tomorrow Night Eighties
printf "\033]4;0;#000000;1;#f2777a;2;#99cc99;3;#ffcc66;4;#6699cc;5;#cc99cc;6;#66cccc;7;#ffffff;8;#000000;9;#f2777a;10;#99cc99;11;#ffcc66;12;#6699cc;13;#cc99cc;14;#66cccc;15;#ffffff\007"
printf "\033]10;#cccccc;#2d2d2d;#cccccc\007"
printf "\033]17;#515151\007"
printf "\033]19;#cccccc\007"
printf "\033]5;0;#cccccc\007"
