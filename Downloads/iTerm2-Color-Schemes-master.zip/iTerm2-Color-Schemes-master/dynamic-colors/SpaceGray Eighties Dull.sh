#!/bin/sh
# SpaceGray Eighties Dull
printf "\033]4;0;#15171c;1;#b24a56;2;#92b477;3;#c6735a;4;#7c8fa5;5;#a5789e;6;#80cdcb;7;#b3b8c3;8;#555555;9;#ec5f67;10;#89e986;11;#fec254;12;#5486c0;13;#bf83c1;14;#58c2c1;15;#ffffff\007"
printf "\033]10;#c9c6bc;#222222;#bbbbbb\007"
printf "\033]17;#272e36\007"
printf "\033]19;#ffffff\007"
printf "\033]5;0;#ffffff\007"
