#!/bin/sh
# Cyberdyne
printf "\033]4;0;#080808;1;#ff8373;2;#00c172;3;#d2a700;4;#0071cf;5;#ff90fe;6;#6bffdd;7;#f1f1f1;8;#2e2e2e;9;#ffc4be;10;#d6fcba;11;#fffed5;12;#c2e3ff;13;#ffb2fe;14;#e6e7fe;15;#ffffff\007"
printf "\033]10;#00ff92;#151144;#00ff9c\007"
printf "\033]17;#454d96\007"
printf "\033]19;#f4f4f4\007"
printf "\033]5;0;#8b93ff\007"
