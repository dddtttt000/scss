#!/bin/sh
# Overnight Slumber
printf "\033]4;0;#0a1222;1;#ffa7c4;2;#85cc95;3;#ffcb8b;4;#8dabe1;5;#c792eb;6;#78ccf0;7;#ffffff;8;#575656;9;#ffa7c4;10;#85cc95;11;#ffcb8b;12;#8dabe1;13;#c792eb;14;#ffa7c4;15;#ffffff\007"
printf "\033]10;#ced2d6;#0e1729;#ffa7c4\007"
printf "\033]17;#1f2b41\007"
printf "\033]19;#ced2d6\007"
printf "\033]5;0;#ffcb8b\007"
