#!/bin/sh
# Peppermint
printf "\033]4;0;#353535;1;#e74669;2;#89d287;3;#dab853;4;#449fd0;5;#da62dc;6;#65aaaf;7;#b4b4b4;8;#535353;9;#e4859b;10;#a3cca2;11;#e1e487;12;#6fbce2;13;#e586e7;14;#96dcdb;15;#dfdfdf\007"
printf "\033]10;#c8c8c8;#000000;#bbbbbb\007"
printf "\033]17;#e6e6e6\007"
printf "\033]19;#000000\007"
printf "\033]5;0;#e0001c\007"
