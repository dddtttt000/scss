#!/bin/sh
# UltraDark
printf "\033]4;0;#000000;1;#f07178;2;#c3e88d;3;#ffcb6b;4;#82aaff;5;#c792ea;6;#89ddff;7;#cccccc;8;#333333;9;#f6a9ae;10;#dbf1ba;11;#ffdfa6;12;#b4ccff;13;#ddbdf2;14;#b8eaff;15;#ffffff\007"
printf "\033]10;#ffffff;#000000;#fefefe\007"
printf "\033]17;#222222\007"
printf "\033]19;#cccccc\007"
printf "\033]5;0;#ffffff\007"
