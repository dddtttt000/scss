#!/bin/sh
# MaterialOcean
printf "\033]4;0;#546e7a;1;#ff5370;2;#c3e88d;3;#ffcb6b;4;#82aaff;5;#c792ea;6;#89ddff;7;#ffffff;8;#546e7a;9;#ff5370;10;#c3e88d;11;#ffcb6b;12;#82aaff;13;#c792ea;14;#89ddff;15;#ffffff\007"
printf "\033]10;#8f93a2;#0f111a;#ffcc00\007"
printf "\033]17;#1f2233\007"
printf "\033]19;#8f93a2\007"
printf "\033]5;0;#8f93a2\007"
