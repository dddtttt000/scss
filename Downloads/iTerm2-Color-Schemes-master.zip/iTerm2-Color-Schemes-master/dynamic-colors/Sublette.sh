#!/bin/sh
# Sublette
printf "\033]4;0;#253045;1;#ee5577;2;#55ee77;3;#ffdd88;4;#5588ff;5;#ff77cc;6;#44eeee;7;#f5f5da;8;#405570;9;#ee6655;10;#99ee77;11;#ffff77;12;#77bbff;13;#aa88ff;14;#55ffbb;15;#ffffee\007"
printf "\033]10;#ccced0;#202535;#ccced0\007"
printf "\033]17;#ccced0\007"
printf "\033]19;#202535\007"
printf "\033]5;0;#ccced0\007"
