#!/bin/sh
# AtomOneLight
printf "\033]4;0;#000000;1;#de3e35;2;#3f953a;3;#d2b67c;4;#2f5af3;5;#950095;6;#3f953a;7;#bbbbbb;8;#000000;9;#de3e35;10;#3f953a;11;#d2b67c;12;#2f5af3;13;#a00095;14;#3f953a;15;#ffffff\007"
printf "\033]10;#2a2c33;#f9f9f9;#bbbbbb\007"
printf "\033]17;#ededed\007"
printf "\033]19;#2a2c33\007"
printf "\033]5;0;#000000\007"
