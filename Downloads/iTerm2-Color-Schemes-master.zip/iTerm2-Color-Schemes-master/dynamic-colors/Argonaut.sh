#!/bin/sh
# Argonaut
printf "\033]4;0;#232323;1;#ff000f;2;#8ce10b;3;#ffb900;4;#008df8;5;#6d43a6;6;#00d8eb;7;#ffffff;8;#444444;9;#ff2740;10;#abe15b;11;#ffd242;12;#0092ff;13;#9a5feb;14;#67fff0;15;#ffffff\007"
printf "\033]10;#fffaf4;#0e1019;#ff0018\007"
printf "\033]17;#002a3b\007"
printf "\033]19;#ffffff\007"
printf "\033]5;0;#9e9c9a\007"
