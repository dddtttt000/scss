#!/bin/sh
# Atom
printf "\033]4;0;#000000;1;#fd5ff1;2;#87c38a;3;#ffd7b1;4;#85befd;5;#b9b6fc;6;#85befd;7;#e0e0e0;8;#000000;9;#fd5ff1;10;#94fa36;11;#f5ffa8;12;#96cbfe;13;#b9b6fc;14;#85befd;15;#e0e0e0\007"
printf "\033]10;#c5c8c6;#161719;#d0d0d0\007"
printf "\033]17;#444444\007"
printf "\033]19;#c5c8c6\007"
printf "\033]5;0;#c5c8c6\007"
