#!/bin/sh
# Espresso
printf "\033]4;0;#353535;1;#d25252;2;#a5c261;3;#ffc66d;4;#6c99bb;5;#d197d9;6;#bed6ff;7;#eeeeec;8;#535353;9;#f00c0c;10;#c2e075;11;#e1e48b;12;#8ab7d9;13;#efb5f7;14;#dcf4ff;15;#ffffff\007"
printf "\033]10;#ffffff;#323232;#d6d6d6\007"
printf "\033]17;#5b5b5b\007"
printf "\033]19;#ffffff\007"
printf "\033]5;0;#ffffff\007"
