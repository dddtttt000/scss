#!/bin/sh
# Chester
printf "\033]4;0;#080200;1;#fa5e5b;2;#16c98d;3;#ffc83f;4;#288ad6;5;#d34590;6;#28ddde;7;#e7e7e7;8;#6f6b68;9;#fa5e5b;10;#16c98d;11;#feef6d;12;#278ad6;13;#d34590;14;#27dede;15;#ffffff\007"
printf "\033]10;#ffffff;#2c3643;#b4b1b1\007"
printf "\033]17;#67747c\007"
printf "\033]19;#ffffff\007"
printf "\033]5;0;#ffffff\007"
