#!/bin/sh
# Galaxy
printf "\033]4;0;#000000;1;#f9555f;2;#21b089;3;#fef02a;4;#589df6;5;#944d95;6;#1f9ee7;7;#bbbbbb;8;#555555;9;#fa8c8f;10;#35bb9a;11;#ffff55;12;#589df6;13;#e75699;14;#3979bc;15;#ffffff\007"
printf "\033]10;#ffffff;#1d2837;#bbbbbb\007"
printf "\033]17;#b5d5ff\007"
printf "\033]19;#000000\007"
printf "\033]5;0;#ffffff\007"
