#!/bin/sh
# Broadcast
printf "\033]4;0;#000000;1;#da4939;2;#519f50;3;#ffd24a;4;#6d9cbe;5;#d0d0ff;6;#6e9cbe;7;#ffffff;8;#323232;9;#ff7b6b;10;#83d182;11;#ffff7c;12;#9fcef0;13;#ffffff;14;#a0cef0;15;#ffffff\007"
printf "\033]10;#e6e1dc;#2b2b2b;#ffffff\007"
printf "\033]17;#5a647e\007"
printf "\033]19;#e6e1dc\007"
printf "\033]5;0;#e6e1dc\007"
