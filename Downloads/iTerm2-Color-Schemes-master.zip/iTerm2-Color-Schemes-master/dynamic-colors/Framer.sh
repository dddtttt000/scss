#!/bin/sh
# Framer
printf "\033]4;0;#141414;1;#ff5555;2;#98ec65;3;#ffcc33;4;#00aaff;5;#aa88ff;6;#88ddff;7;#cccccc;8;#414141;9;#ff8888;10;#b6f292;11;#ffd966;12;#33bbff;13;#cebbff;14;#bbecff;15;#ffffff\007"
printf "\033]10;#777777;#111111;#fcdc08\007"
printf "\033]17;#666666\007"
printf "\033]19;#ffffff\007"
printf "\033]5;0;#fefdbf\007"
