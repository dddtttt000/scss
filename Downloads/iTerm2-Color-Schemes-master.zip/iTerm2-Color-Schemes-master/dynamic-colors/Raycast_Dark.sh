#!/bin/sh
# Raycast_Dark
printf "\033]4;0;#000000;1;#ff5360;2;#59d499;3;#ffc531;4;#56c2ff;5;#cf2f98;6;#52eee5;7;#ffffff;8;#000000;9;#ff6363;10;#59d499;11;#ffc531;12;#56c2ff;13;#cf2f98;14;#52eee5;15;#ffffff\007"
printf "\033]10;#ffffff;#1a1a1a;#cccccc\007"
printf "\033]17;#333333\007"
printf "\033]19;#000000\007"
printf "\033]5;0;#ffffff\007"
